class AppConstant {
  static final users = <User>[
    const User(
      username: 'Тимур',
      password: '202609422',
    ),
    const User(
      username: 'Наташа',
      password: '12345',
    ),
    const User(
      username: 'Савлелий',
      password: 'qwerty',
    ),
    const User(
      username: 'Алексей',
      password: '1124',
    ),
    const User(
      username: 'Admin',
      password: 'admin',
    ),
  ];

  static final groups = <Groups>[
    Groups(
      name: 'ИС101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Аглиулин Тимур'),
        Student(name: 'Козырнов Игорь'),
        Student(name: 'Артём Фоминых'),
        Student(name: 'Михаил Харченко'),
        Student(name: 'Карина Паньшина'),
        Student(name: 'Елизавета Головач'),
      ],
    ),
    Groups(
      name: 'ФИ101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Тарас Шапаренко'),
        Student(name: 'Сергей Макаров'),
        Student(name: 'Татьяна Ивлева'),
      ],
    ),
    Groups(
      name: 'УТ101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Иванова Екатерина'),
        Student(name: 'Смирнов Павел'),
        Student(name: 'Кузнецова Анастасия'),
      ],
    ),
    Groups(
      name: 'ЭУ101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Сидорова Ольга'),
        Student(name: 'Карпов Даниил'),
        Student(name: 'Белова Виктория'),
      ],
    ),
  ];

  static final lessons = <Lessons>[
    Lessons(
      name: 'Проектирование информационных систем',
      groups: groups,
    ),
    Lessons(
      name: 'Качество, надежность и тестирование информационных систем',
      groups: groups,
    ),
    Lessons(
      name: 'Технологии баз данных',
      groups: groups,
    ),
    Lessons(
      name: 'Разработка приложений для мобильных устройств',
      groups: groups,
    ),
  ];
}

class User {
  final String username;
  final String password;

  const User({
    required this.username,
    required this.password,
  });
}

class Groups {
  String? name;
  List<Student>? students;
  List<Date>? date;

  Groups({
    this.name,
    this.students,
    this.date,
  });
}

class Lessons {
  String name;
  List<Groups>? groups;

  Lessons({
    required this.name,
    this.groups,
  });
}

class Student {
  String name;
  String? rating;
  bool isPresent;

  Student({
    required this.name,
    this.rating,
    this.isPresent = false,
  });
}

class Date {
  String date;

  Date({
    required this.date,
  });
}