import 'package:flutter/material.dart';
import 'package:untitled2/DB/database.dart';
import 'package:untitled2/pages/students_page.dart';

class DateLessonsPage extends StatefulWidget {
  final Groups group;

  const DateLessonsPage({Key? key, required this.group}) : super(key: key);

  @override
  _DateLessonsPageState createState() => _DateLessonsPageState();
}

class _DateLessonsPageState extends State<DateLessonsPage> {
  TextEditingController _dateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Расписание ${widget.group.name}'),
      ),
      body: ListView.builder(
        itemCount: widget.group.date?.length ?? 0,
        itemBuilder: (context, index) {
          final date = widget.group.date![index];
          return ListTile(
            title: Text(date.date),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    _dateController.text = date.date;
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Редактировать дату'),
                        content: TextField(
                          controller: _dateController,
                          decoration: InputDecoration(labelText: 'Дата'),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Отмена'),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                date.date = _dateController.text;
                              });
                              Navigator.of(context).pop();
                            },
                            child: Text('Сохранить'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    setState(() {
                      widget.group.date!.removeAt(index);
                    });
                  },
                ),
              ],
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => StudentsPage(group: widget.group, date: date),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Добавить дату'),
              content: TextField(
                controller: _dateController,
                decoration: InputDecoration(labelText: 'Дата'),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('Отмена'),
                ),
                TextButton(
                  onPressed: () {
                    final newDate = Date(date: _dateController.text);
                    setState(() {
                      widget.group.date!.add(newDate);
                    });
                    _dateController.clear();
                    Navigator.of(context).pop();
                  },
                  child: Text('Добавить'),
                ),
              ],
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
