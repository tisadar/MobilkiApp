import 'package:flutter/material.dart';
import 'package:untitled2/DB/database.dart';

class StudentsPage extends StatefulWidget {
  final Groups group;
  final Date date;

  const StudentsPage({Key? key, required this.group, required this.date}) : super(key: key);

  @override
  _StudentsPageState createState() => _StudentsPageState();
}

class _StudentsPageState extends State<StudentsPage> {
  TextEditingController _studentNameController = TextEditingController();
  TextEditingController _studentRatingController = TextEditingController();
  bool _isPresent = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Студенты группы ${widget.group.name}'),
      ),
      body: ListView.builder(
        itemCount: widget.group.students?.length ?? 0,
        itemBuilder: (context, index) {
          final student = widget.group.students![index];
          return ListTile(
            title: Text(student.name),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Оценка: ${student.rating ?? 'N/A'}'),
                Text('Присутствие: ${student.isPresent ? 'Присутствует' : 'Отсутствует'}'),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    _studentNameController.text = student.name;
                    _studentRatingController.text = student.rating ?? '';
                    _isPresent = student.isPresent;
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Редактировать студента'),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(height: 8),
                            TextField(
                              controller: _studentNameController,
                              decoration: InputDecoration(labelText: 'Имя студента'),
                            ),
                            SizedBox(height: 8),
                            TextField(
                              controller: _studentRatingController,
                              decoration: InputDecoration(labelText: 'Оценка'),
                            ),
                            Row(
                              children: [
                                Checkbox(
                                  value: _isPresent,
                                  onChanged: (value) {
                                    setState(() {
                                      _isPresent = value!;
                                    });
                                  },
                                ),
                                Text('Присутствует')
                              ],
                            ),
                          ],
                        ),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Отмена'),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                student.name = _studentNameController.text;
                                student.rating = _studentRatingController.text;
                                student.isPresent = _isPresent;
                              });
                              Navigator.of(context).pop();
                            },
                            child: Text('Сохранить'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    setState(() {
                      widget.group.students!.removeAt(index);
                    });
                  },
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _studentNameController.clear();
          _studentRatingController.clear();
          _isPresent = false;
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Добавить студента'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 8),
                  TextField(
                    controller: _studentNameController,
                    decoration: InputDecoration(labelText: 'Имя студента'),
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: _studentRatingController,
                    decoration: InputDecoration(labelText: 'Оценка'),
                  ),
                  Row(
                    children: [
                      Checkbox(
                        value: _isPresent,
                        onChanged: (value) {
                          setState(() {
                            _isPresent = value!;
                          });
                        },
                      ),
                      Text('Присутствует')
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('Отмена'),
                ),
                TextButton(
                  onPressed: () {
                    final newStudent = Student(
                      name: _studentNameController.text,
                      rating: _studentRatingController.text,
                      isPresent: _isPresent,
                    );

                    setState(() {
                      widget.group.students!.add(newStudent);
                    });
                    Navigator.of(context).pop();
                  },
                  child: Text('Добавить'),
                ),
              ],
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
