import 'package:flutter/material.dart';
import 'package:untitled2/DB/database.dart';
import 'package:untitled2/pages/groups_page.dart';

class LearningPage extends StatefulWidget {
  const LearningPage({Key? key}) : super(key: key);

  @override
  _LearningPageState createState() => _LearningPageState();
}

class _LearningPageState extends State<LearningPage> {
  TextEditingController _lessonNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Предметы'),
      ),
      body: ListView.builder(
        itemCount: AppConstant.lessons.length,
        itemBuilder: (context, index) {
          final lesson = AppConstant.lessons[index];
          return ListTile(
            title: Text(lesson.name),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    _lessonNameController.text = lesson.name;
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Редактировать предмет'),
                        content: TextField(
                          controller: _lessonNameController,
                          decoration: InputDecoration(labelText: 'Название предмета'),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Отмена'),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                lesson.name = _lessonNameController.text;
                              });
                              Navigator.of(context).pop();
                            },
                            child: Text('Сохранить'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    setState(() {
                      AppConstant.lessons.removeAt(index);
                    });
                  },
                ),
              ],
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => GroupsPage(lesson: lesson),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Добавить предмет'),
              content: TextField(
                controller: _lessonNameController,
                decoration: InputDecoration(labelText: 'Название предмета'),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('Отмена'),
                ),
                TextButton(
                  onPressed: () {
                    final newLesson = Lessons(name: _lessonNameController.text);
                    setState(() {
                      AppConstant.lessons.add(newLesson);
                    });
                    _lessonNameController.clear();
                    Navigator.of(context).pop();
                  },
                  child: Text('Добавить'),
                ),
              ],
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
