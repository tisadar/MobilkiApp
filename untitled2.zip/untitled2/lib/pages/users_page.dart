import 'package:flutter/material.dart';
import 'package:untitled2/DB/database.dart';

class UsersPage extends StatefulWidget {
  const UsersPage({Key? key}) : super(key: key);

  @override
  _UsersPageState createState() => _UsersPageState();
}

class _UsersPageState extends State<UsersPage> {
  TextEditingController _newUsernameController = TextEditingController();
  TextEditingController _newPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Пользователи'),
      ),
      body: ListView.builder(
        itemCount: AppConstant.users.length,
        itemBuilder: (context, index) {
          final user = AppConstant.users[index];
          return ListTile(
            title: Text(user.username),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Удалить пользователя'),
                    content: Text('Вы уверены, что хотите удалить пользователя ${user.username}?'),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text('Отмена'),
                      ),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            AppConstant.users.removeAt(index);
                          });
                          Navigator.of(context).pop();
                        },
                        child: Text('Удалить'),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Добавить пользователя'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 8),
                  TextField(
                    controller: _newUsernameController,
                    decoration: InputDecoration(labelText: 'Логин'),
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: _newPasswordController,
                    decoration: InputDecoration(labelText: 'Пароль'),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('Отмена'),
                ),
                TextButton(
                  onPressed: () {
                    final newUser = User(
                      username: _newUsernameController.text,
                      password: _newPasswordController.text,
                    );
                    setState(() {
                      AppConstant.users.add(newUser);
                    });
                    _newUsernameController.clear();
                    _newPasswordController.clear();
                    Navigator.of(context).pop();
                  },
                  child: Text('Добавить'),
                ),
              ],
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
