import 'package:flutter/material.dart';
import 'package:untitled2/DB/database.dart';
import 'package:untitled2/pages/datelesson_page.dart';

class GroupsPage extends StatefulWidget {
  final Lessons lesson;

  const GroupsPage({Key? key, required this.lesson}) : super(key: key);

  @override
  _GroupsPageState createState() => _GroupsPageState();
}

class _GroupsPageState extends State<GroupsPage> {
  TextEditingController _groupNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Группы изучающие ${widget.lesson.name}'),
      ),
      body: ListView.builder(
        itemCount: widget.lesson.groups?.length ?? 0,
        itemBuilder: (context, index) {
          final group = widget.lesson.groups![index];
          return ListTile(
            title: Text(group.name ?? ''),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    _groupNameController.text = group.name ?? '';
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Редактировать группу'),
                        content: TextField(
                          controller: _groupNameController,
                          decoration: InputDecoration(labelText: 'Название группы'),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Отмена'),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                group.name = _groupNameController.text;
                              });
                              Navigator.of(context).pop();
                            },
                            child: Text('Сохранить'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    setState(() {
                      widget.lesson.groups!.removeAt(index);
                    });
                  },
                ),
              ],
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DateLessonsPage(group: group),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Добавить группу'),
              content: TextField(
                controller: _groupNameController,
                decoration: InputDecoration(labelText: 'Название группы'),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('Отмена'),
                ),
                TextButton(
                  onPressed: () {
                    final newGroup = Groups(name: _groupNameController.text);
                    setState(() {
                      widget.lesson.groups!.add(newGroup);
                    });
                    _groupNameController.clear();
                    Navigator.of(context).pop();
                  },
                  child: Text('Добавить'),
                ),
              ],
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
