import 'package:flutter/material.dart';
import 'package:untitled2/DB/database.dart';
import 'package:untitled2/pages/navigation_page.dart';

class LoginPage extends StatefulWidget {
  final VoidCallback toggleTheme;
  final bool isDarkTheme;

  const LoginPage({Key? key, required this.toggleTheme, required this.isDarkTheme}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _usernameController = TextEditingController(text: 'Тимур');
  final _passwordController = TextEditingController(text: '202609422');
  String _errorText = '';

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _handleLogin() {
    final username = _usernameController.text;
    final password = _passwordController.text;

    if (username.isEmpty) {
      setState(() {
        _errorText = 'Введите логин';
      });
    } else if (password.isEmpty) {
      setState(() {
        _errorText = 'Введите пароль';
      });
    } else {
      final isValidUser = AppConstant.users
          .where((user) => user.username == username && user.password == password)
          .isNotEmpty;

      if (isValidUser) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NavigationPage(toggleTheme: widget.toggleTheme, isDarkTheme: widget.isDarkTheme),
          ),
        );
      } else {
        setState(() {
          _errorText = 'Пароль или логин неверен';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: const Text('Вход в систему'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 100),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Введите данные от вашего аккаунта',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(
                  labelText: 'Логин',
                  prefixIcon: const Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Пароль',
                  prefixIcon: const Icon(Icons.lock),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                _errorText,
                textAlign: TextAlign.start,
                style: const TextStyle(
                  color: Colors.red,
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _handleLogin,
                child: const Text('Вход'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: widget.toggleTheme,
        child: Icon(widget.isDarkTheme ? Icons.wb_sunny : Icons.nights_stay),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
    );
  }
}
