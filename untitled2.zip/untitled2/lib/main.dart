import 'package:flutter/material.dart';
import 'pages/login_page.dart';
import 'tema.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDarkTheme = false;

  void _toggleTheme() {
    setState(() {
      _isDarkTheme = !_isDarkTheme;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Demo',
      theme: _isDarkTheme ? MyTheme.darkTheme : MyTheme.lightTheme,
      home: LoginPage(toggleTheme: _toggleTheme, isDarkTheme: _isDarkTheme),
    );
  }
}
