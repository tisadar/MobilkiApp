import 'package:mobile_app/src/feature/groups_details/groups_details.dart';
import 'package:flutter/material.dart';
import 'src/src.dart';

void main() async {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color.fromARGB(255, 178, 243, 178),
        scaffoldBackgroundColor: const Color.fromARGB(255, 230, 255, 230),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color.fromARGB(255, 178, 243, 178),
          foregroundColor: Colors.black, // Text color for AppBar
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color.fromARGB(255, 178, 243, 178),
          ),
        ),
        buttonTheme: const ButtonThemeData(
          buttonColor: Color.fromARGB(255, 178, 243, 178),
          textTheme: ButtonTextTheme.primary,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color.fromARGB(255, 178, 243, 178),
        ),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Color.fromARGB(255, 230, 255, 230),
        ),
      ),
      routes: {
        '/': (BuildContext context) => const SignInPage(),
        '/users': (BuildContext context) => const UsersPage(),
        '/lessons': (BuildContext context) => const LessonsPage(),
        '/groups_details': (BuildContext context) => const GroupsDetailsPage(),
      },
      onGenerateRoute: (RouteSettings settings) {
        final args = settings.arguments;

        switch (settings.name) {
          case '/':
            return MaterialPageRoute(
              builder: (context) => const SignInPage(),
            );
          case '/users':
            return MaterialPageRoute(
              builder: (context) => const UsersPage(),
            );
          case '/groups':
            return MaterialPageRoute(
              builder: (context) => GroupPage(
                groups: args as List<Groups>,
              ),
            );
          case '/groups_details':
            return MaterialPageRoute(
              builder: (context) => const GroupsDetailsPage(),
            );
          case '/student_list':
            return MaterialPageRoute(
              builder: (context) => StudentListPage(
                students: args as List<Student>? ?? <Student>[],
              ),
            );
          case '/time_table':
            final timeTableArgs = args as TimeTableArguments;
            return MaterialPageRoute(
              builder: (context) => TimeTablePage(
                details: timeTableArgs.details,
                students: timeTableArgs.students,
              ),
            );
          case '/students':
            return MaterialPageRoute(
              builder: (context) => StudentsPage(
                details: args as List<Student>?,
              ),
            );
          case '/student_detail':
            return MaterialPageRoute(
              builder: (context) => StudentDetailPage(
                details: args as Student,
              ),
            );
        }
        return null;
      },
    ),
  );
}

class TimeTableArguments {
  final List<Date> details;
  final List<Student> students;

  TimeTableArguments({
    required this.details,
    required this.students,
  });
}

