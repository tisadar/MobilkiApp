class AppConstant {
  static final users = <Users>[
    const Users(
      login: 'Тимур',
      password: '202609422',
    ),
    const Users(
      login: 'Наташа',
      password: '12345',
    ),
    const Users(
      login: 'Савлелий',
      password: 'qwerty',
    ),
    const Users(
      login: 'Алексей',
      password: '1124',
    ),
    const Users(
      login: 'Admin',
      password: 'admin',
    ),
  ];

  static final groups = <Groups>[
    Groups(
      name: 'ИС101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Аглиулин Тимур'),
        Student(name: 'Козырнов Игорь'),
        Student(name: 'Артём Фоминых'),
        Student(name: 'Михаил Харченко'),
        Student(name: 'Карина Паньшина'),
        Student(name: 'Елизавета Головач'),
      ],
    ),
    Groups(
      name: 'ФИ101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Тарас Шапаренко'),
        Student(name: 'Сергей Макаров'),
        Student(name: 'Татьяна Ивлева'),
      ],
    ),
    Groups(
      name: 'УТ101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Иванова Екатерина'),
        Student(name: 'Смирнов Павел'),
        Student(name: 'Кузнецова Анастасия'),
      ],
    ),
    Groups(
      name: 'ЭУ101',
      date: <Date>[
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024'),
        Date(date: '05.03.2024')
      ],
      students: <Student>[
        Student(name: 'Сидорова Ольга'),
        Student(name: 'Карпов Даниил'),
        Student(name: 'Белова Виктория'),
      ],
    ),
  ];

  static final lessons = <Lessons>[
    Lessons(
      name: 'Проектирование информационных систем',
      groups: groups,
    ),
    Lessons(
      name: 'Качество, надежность и тестирование информационных систем',
      groups: groups,
    ),
    Lessons(
      name: 'Технологии баз данных',
      groups: groups,
    ),
    Lessons(
      name: 'Разработка приложений для мобильных устройств',
      groups: groups,
    ),
  ];
}

class Users {
  final String login;
  final String password;

  const Users({
    required this.login,
    required this.password,
  });
}

class Groups {
  final String? name;
  List<Student>? students;
  List<Date>? date;

  Groups({
    this.name,
    this.students,
    this.date,
  });
}

class Lessons {
  final String name;
  List<Groups>? groups;

  Lessons({
    required this.name,
    this.groups,
  });
}

class Student {
  String name;
  String? rating;

  Student({
    required this.name,
    this.rating,
  });
}

class Date {
  String date;

  Date({
    required this.date,
  });
}
