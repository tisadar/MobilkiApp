export 'view/student_detail_page.dart';
