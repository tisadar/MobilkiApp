import 'package:mobile_app/src/core/core.dart';
import 'package:flutter/material.dart';

class StudentDetailPage extends StatefulWidget {
  final Student details;

  const StudentDetailPage({
    required this.details,
    super.key,
  });

  @override
  State<StudentDetailPage> createState() => _StudentDetailPageState();
}

class _StudentDetailPageState extends State<StudentDetailPage> {
  final _rateController = TextEditingController();

  @override
  void dispose() {
    _rateController.dispose();
    super.dispose();
  }

  void _addRate() {
    setState(() {
      widget.details.rating = _rateController.text;
    });
  }

  void _leave() {
    setState(() {
      widget.details.rating = 'Пропуск';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.details.name),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 100),
            const Text(
              'Оценка за занятие',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
            TextField(
              controller: _rateController,
            ),
            const SizedBox(height: 8),
            Center(
              child: Row(
                children: [
                  ElevatedButton(
                    onPressed: _addRate,
                    child: const Text(
                      'Поставить оценку',
                    ),
                  ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: _leave,
                    child: const Text(
                      'Пропуск',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Текущая оценка: ${widget.details.rating ?? 'Не указана'}',
              style: const TextStyle(
                fontSize: 16,
              ),
            )
          ],
        ),
      ),
    );
  }
}
