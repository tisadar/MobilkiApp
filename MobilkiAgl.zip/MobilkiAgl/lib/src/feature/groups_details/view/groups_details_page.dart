import 'package:mobile_app/main.dart';
import 'package:mobile_app/src/src.dart';
import 'package:flutter/material.dart';

class GroupsDetailsPage extends StatelessWidget {
  const GroupsDetailsPage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as Groups;

    return Scaffold(
      appBar: AppBar(
        title: Text(args.name ?? ''),
      ),
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 100),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(
                  context,
                  '/student_list',
                  arguments: args.students,
                );
              },
              child: const Text(
                'Обучающиеся',
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(
                  context,
                  '/time_table',
                  arguments: TimeTableArguments(
                    details: args.date ?? <Date>[],
                    students: args.students ?? <Student>[],
                  ),
                );
              },
              child: const Text(
                'Расписание',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
