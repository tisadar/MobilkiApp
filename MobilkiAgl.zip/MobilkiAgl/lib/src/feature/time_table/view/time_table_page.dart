import 'package:collection/collection.dart';
import 'package:flutter/material.dart';

import 'package:mobile_app/src/core/core.dart';

class TimeTablePage extends StatefulWidget {
  final List<Date>? details;
  final List<Student>? students;

  const TimeTablePage({
    required this.details,
    required this.students,
    super.key,
  });

  @override
  State<TimeTablePage> createState() => _TimeTablePageState();
}

class _TimeTablePageState extends State<TimeTablePage> {
  final _dateController = TextEditingController();

  @override
  void dispose() {
    _dateController.dispose();
    super.dispose();
  }

  void _actionDelete(String? dateTime) {
    setState(
      () {
        widget.details?.removeWhere(
          (date) => date.date == dateTime,
        );
      },
    );
  }

  void _actionAdd() {
    if (_dateController.text.isNotEmpty) {
      setState(
        () {
          final newDate = Date(
            date: _dateController.text,
          );
          widget.details?.add(newDate);
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Расписание'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            const SizedBox(height: 100),
            ListView.builder(
              itemCount: widget.details?.length ?? 0,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                final date = widget.details?[index];
                return Material(
                  type: MaterialType.transparency,
                  child: InkWell(
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        '/students',
                        arguments: widget.students,
                      );
                    },
                    child: Row(
                      children: [
                        Text(
                          date?.date ?? '',
                          style: const TextStyle(fontSize: 16),
                        ),
                        const Spacer(),
                        ElevatedButton(
                          onPressed: () => _actionDelete(
                            date?.date,
                          ),
                          child: const Text('Удалить'),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _dateController,
                decoration: const InputDecoration(
                  labelText: 'Дата',
                ),
              ),
            ),
            ElevatedButton(
              onPressed: _actionAdd,
              child: const Text('Добавить'),
            ),
          ],
        ),
      ),
    );
  }
}
