import 'package:mobile_app/src/core/core.dart';
import 'package:flutter/material.dart';

class GroupPage extends StatefulWidget {
  final List<Groups> groups;

  const GroupPage({
    required this.groups,
    super.key,
  });

  @override
  State<GroupPage> createState() => _GroupPageState();
}

class _GroupPageState extends State<GroupPage> {
  final _nameController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _actionDelete(Groups group) {
    setState(
      () {
        widget.groups.removeWhere(
          (element) => element == group,
        );
      },
    );
  }

  void _actionAdd() {
    if (_nameController.text.isNotEmpty) {
      setState(
        () {
          widget.groups.add(
            Groups(
              name: _nameController.text,
              students: <Student>[],
              date: <Date>[],
            ),
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Группы',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 100),
        child: Column(
          children: [
            ListView.builder(
              shrinkWrap: true,
              itemCount: widget.groups.length,
              itemBuilder: (context, index) {
                final groups = widget.groups[index];
                return Material(
                  type: MaterialType.transparency,
                  child: InkWell(
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        '/groups_details',
                        arguments: groups,
                      );
                    },
                    child: Row(
                      children: [
                        Text(
                          groups.name ?? '',
                          style: const TextStyle(fontSize: 16),
                        ),
                        const Spacer(),
                        ElevatedButton(
                          onPressed: () => _actionDelete(groups),
                          child: const Text('Удалить'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                hintText: 'Добавить группу',
              ),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _actionAdd,
              child: const Text('Добавить'),
            ),
          ],
        ),
      ),
    );
  }
}
