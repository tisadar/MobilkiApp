import 'package:mobile_app/src/core/core.dart';
import 'package:flutter/material.dart';

class StudentsPage extends StatefulWidget {
  final List<Student>? details;

  const StudentsPage({
    required this.details,
    super.key,
  });

  @override
  State<StudentsPage> createState() => _StudentsPageState();
}

class _StudentsPageState extends State<StudentsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Студенты'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 100),
          ListView.builder(
            itemCount: widget.details?.length ?? 0,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              final student = widget.details?[index];
              return Material(
                type: MaterialType.transparency,
                child: InkWell(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      '/student_detail',
                      arguments: student,
                    );
                  },
                  child: Row(
                    children: [
                      Container(
                        decoration: const BoxDecoration(color: Colors.white38),
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: Text(
                          student?.name ?? '',
                          style: const TextStyle(fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
