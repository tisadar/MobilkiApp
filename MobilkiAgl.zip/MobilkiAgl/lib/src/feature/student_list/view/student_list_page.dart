import 'package:mobile_app/src/core/core.dart';
import 'package:flutter/material.dart';

class StudentListPage extends StatefulWidget {
  final List<Student> students;

  const StudentListPage({
    required this.students,
    super.key,
  });

  @override
  State<StudentListPage> createState() => _StudentListPageState();
}

class _StudentListPageState extends State<StudentListPage> {
  final _studentController = TextEditingController();

  void _addStudent() {
    setState(() {
      widget.students.add(
        Student(
          name: _studentController.text,
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Обущающиеся'),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            const SizedBox(height: 100),
            ListView.builder(
              shrinkWrap: true,
              itemCount: widget.students.length,
              itemBuilder: (context, index) {
                final student = widget.students[index];
                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: Text(
                    student.name,
                    style: const TextStyle(fontSize: 16),
                  ),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _studentController,
                decoration: const InputDecoration(
                  labelText: 'Студент',
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () => _addStudent(),
              child: const Text('Добавить студента'),
            ),
          ],
        ),
      ),
    );
  }
}
