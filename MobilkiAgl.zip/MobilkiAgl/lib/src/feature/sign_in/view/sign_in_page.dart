import 'package:mobile_app/src/src.dart';
import 'package:flutter/material.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({
    super.key,
  });

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final _loginController = TextEditingController(text: 'Тимур');
  final _passwordController = TextEditingController(text: '202609422');
  String _errorMessage = '';

  @override
  void dispose() {
    _loginController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _action() {
    final login = _loginController.text;
    final password = _passwordController.text;

    if (_loginController.text.isEmpty) {
      setState(
        () {
          _errorMessage = 'ВВЕДИТЕ логин';
        },
      );
    } else if (_passwordController.text.isEmpty) {
      setState(
        () {
          _errorMessage = 'ВВЕДИТЕ пароль';
        },
      );
    }

    final comparison = AppConstant.users
        .where(
          (users) => users.login == login && users.password == password,
        )
        .isNotEmpty;

    if (comparison) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const HomePage(),
        ),
      );
    } else {
      setState(
        () {
          _errorMessage = 'Пароль или логин неверен';
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: const Text(
          'Вход в сисему',
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 100),
          child: Column(
            children: [
              const Text(
                'Введите данные от вашего акаунта',
                style: TextStyle(fontSize: 16),
              ),
              TextField(
                controller: _loginController,
              ),
              TextField(
                controller: _passwordController,
                obscureText: true,
              ),
              Text(
                _errorMessage,
                textAlign: TextAlign.start,
                style: const TextStyle(
                  color: Colors.red,
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _action,
                child: const Text('Вход'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
