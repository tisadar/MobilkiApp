import 'package:mobile_app/src/core/core.dart';
import 'package:flutter/material.dart';

class UsersPage extends StatefulWidget {
  const UsersPage({
    super.key,
  });

  @override
  State<UsersPage> createState() => _UsersPageState();
}

class _UsersPageState extends State<UsersPage> {
  final _loginController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _loginController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _actionDelete(Users users) {
    setState(
      () {
        AppConstant.users.removeWhere(
          (element) => element == users,
        );
      },
    );
  }

  void _actionAdd() {
    if (_loginController.text.isNotEmpty &&
        _passwordController.text.isNotEmpty) {
      setState(
        () {
          AppConstant.users.add(
            Users(
              login: _loginController.text,
              password: _passwordController.text,
            ),
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Пользователи',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 50),
        child: Column(
          children: [
            ListView.builder(
              shrinkWrap: true,
              itemCount: AppConstant.users.length,
              itemBuilder: (context, index) {
                final users = AppConstant.users[index];
                return Row(
                  children: [
                    Text(users.login),
                    const Spacer(),
                    ElevatedButton(
                      onPressed: () => _actionDelete(users),
                      child: const Text('Удалить'),
                    ),
                  ],
                );
              },
            ),
            TextField(
              controller: _loginController,
              decoration: const InputDecoration(hintText: 'Логин'),
            ),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(hintText: 'Пароль'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _actionAdd,
              child: const Text('Добавить'),
            ),
          ],
        ),
      ),
    );
  }
}
