import 'package:flutter/material.dart';
import 'package:mobile_app/src/src.dart';

class LessonsPage extends StatefulWidget {
  const LessonsPage({
    super.key,
  });

  @override
  State<LessonsPage> createState() => _LessonsPageState();
}

class _LessonsPageState extends State<LessonsPage> {
  final _lessonController = TextEditingController();

  @override
  void dispose() {
    _lessonController.dispose();
    super.dispose();
  }

  void _addLesson() {
    setState(
      () {
        AppConstant.lessons.add(
          Lessons(
            name: _lessonController.text,
            groups: [],
          ),
        );
      },
    );
  }

  void _deleteLessons(Lessons lessons) {
    setState(
      () {
        AppConstant.lessons.removeWhere(
          (element) => element == lessons,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Предметы',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 100),
        child: Column(
          children: [
            ListView.builder(
              itemCount: AppConstant.lessons.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                final lessons = AppConstant.lessons[index];
                return Material(
                  type: MaterialType.transparency,
                  child: InkWell(
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        '/groups',
                        arguments: lessons.groups,
                      );
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          decoration: const BoxDecoration(
                            color: Colors.white38,
                          ),
                          margin: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          child: Text(
                            lessons.name,
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            _deleteLessons(lessons);
                          },
                          child: const Text('Удалить'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            TextField(
              controller: _lessonController,
              decoration: const InputDecoration(
                hintText: 'Добавить предмет',
              ),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _addLesson,
              child: const Text('Добавить'),
            ),
          ],
        ),
      ),
    );
  }
}
